from django.shortcuts import render, redirect
from django.http import HttpResponse
from pytube import YouTube

# Create your views here.
def ytb_main(request):
    return render(request, 'ytb_main.html')

def ytb_download(request):
    url=request.GET.get('url')
    obj=YouTube(url)
    resolutions=[]
    strm_all=obj.streams.all()
    for i in strm_all:
        resolutions.append(i.resolution)
        resolutions=list(dict.fromkeys(resolutions))

        embed_link=url.replace("watch?v=","embed/")
    return render(request, 'ytb_download.html',{'rsl':resolutions,'embd':embed_link})
