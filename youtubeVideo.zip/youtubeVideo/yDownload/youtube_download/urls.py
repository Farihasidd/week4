from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('',views.ytb_main),
    path('download/',views.ytb_download),
]